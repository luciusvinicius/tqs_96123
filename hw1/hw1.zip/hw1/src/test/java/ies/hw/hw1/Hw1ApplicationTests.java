package ies.hw.hw1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hw1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
