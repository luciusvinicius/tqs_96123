package ies.lab3.lab3_2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab32ApplicationTests {

	@Test
	void contextLoads() {
	}

}
